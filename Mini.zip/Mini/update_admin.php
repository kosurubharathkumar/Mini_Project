<?php
session_start();
@include 'config.php';

if (!isset($_SESSION['admin_name'])) {
    header('Location: login.php');
    exit();
}

if (isset($_POST['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit();
}

$admin_id = $_SESSION['admin_id'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$email = $_POST['email'];
$hname = $_POST['hostel_name'];
$city = $_POST['city'];
$description = $_POST['description'];

$query = "SELECT * FROM admin WHERE admin_id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, 'i', $admin_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$admin_exists = mysqli_num_rows($result) > 0;

if ($admin_exists) {
    $update_query = "UPDATE admin SET name = ?, email = ?, phone = ?, hostel_name = ?, city = ?, description = ? WHERE admin_id = ?";
    $stmt = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($stmt, 'ssssssi', $name, $email, $phone, $hname, $city, $description, $admin_id);
} else {
    $insert_query = "INSERT INTO admin (admin_id, name, email, phone, hostel_name, city, description) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $insert_query);
    mysqli_stmt_bind_param($stmt, 'issssss', $admin_id, $name, $email, $phone, $hname, $city, $description);
}

$success = mysqli_stmt_execute($stmt);

mysqli_stmt_close($stmt);

if ($success) {
    header('Location: profile.php');
    exit();
} else {
    echo "Error: " . mysqli_error($conn);
}

mysqli_close($conn);
?>
