<?php
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $room_id = $_POST['room_id'];
    $user_email = $_POST['user_email'];
    
    // Check room availability
    $sql = "SELECT * FROM rooms WHERE id='$room_id' AND people < capacity";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Update room occupancy status
        $sql = "UPDATE rooms SET people = people + 1, occupancy_status = CASE 
                WHEN people + 1 = capacity THEN 'over occupied'
                WHEN people + 1 < capacity THEN 'partially occupied'
                END
                WHERE id='$room_id'";
        
        if ($conn->query($sql) === TRUE) {
            // Send confirmation email
            $to = $user_email;
            $subject = "Booking Confirmation";
            $message = "Your booking for room $room_id has been confirmed.";
            $headers = "From: noreply@hostel.com";

            mail($to, $subject, $message, $headers);
            echo "Booking successful. Confirmation email sent to $user_email.";
        } else {
            echo "Error updating record: " . $conn->error;
        }
    } else {
        echo "Room is fully occupied or doesn't exist.";
    }
}

// Fetch available rooms
$sql = "SELECT * FROM rooms WHERE people < capacity";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room Booking</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f0f0;
        }
        header {
            background-color: #333;
            color: white;
            padding: 10px 0;
            text-align: center;
        }
        .container {
            padding: 20px;
        }
        .room {
            margin: 20px 0;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: white;
        }
        .room-info {
            flex: 1;
        }
    </style>
</head>
<body>
    <header>
        <h1>Room Booking</h1>
    </header>
    <div class="container">
        <h2>Available Rooms</h2>
        <?php
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "
                <div class='room'>
                    <div class='room-info'>
                        <h3>Room " . $row['room_number'] . "</h3>
                        <p>Capacity: " . $row['capacity'] . "</p>
                        <p>Occupied: " . $row['people'] . "</p>
                        <p>Furniture: " . $row['furniture_type'] . "</p>
                    </div>
                    <form method='POST' action='booking.php'>
                        <input type='hidden' name='room_id' value='" . $row['id'] . "'>
                        <label for='user_email'>Email: </label>
                        <input type='email' name='user_email' required>
                        <button type='submit'>Book Now</button>
                    </form>
                </div>
                ";
            }
        } else {
            echo "<p>No available rooms at the moment.</p>";
        }
        ?>
    </div>
</body>
</html>

<?php
$conn->close();
?>
