<?php 
    @include 'config.php';
?>

<?php
   session_start(); // Start the session 

   // Check if the user is logged in as either admin or user
   $isLoggedIn = isset($_SESSION['admin_id']) || isset($_SESSION['user_id']);
   $isAdmin = isset($_SESSION['admin_id']);
?>

<?php
    $result = $conn->query("SELECT COUNT(*) AS total_hostels FROM hostels");
    $total_hostels = $result->fetch_assoc()['total_hostels'];
    $result = $conn->query("SELECT COUNT(DISTINCT city) AS total_cities FROM hostels");
    $total_cities = $result->fetch_assoc()['total_cities'];
?>

<?php
    $hostel_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

    // If no valid hostel ID is provided, redirect or show an error
    if ($hostel_id <= 0) {
        echo "<p>Invalid hostel ID.</p>";
        exit;
    }

    // Fetch details for the specific hostel
    $sql = "SELECT h.id, h.hostel_name, h.city, h.description, h.num_floors, h.num_rooms, h.email, h.phone, h.hostel_path, 
                   SUM(r.capacity - r.people) AS total_vacancies,
                   MAX(r.length * r.width) AS total_flat_space
            FROM hostels h
            JOIN rooms r ON h.id = r.hostel_id
            WHERE h.id = ?
            GROUP BY h.id";

    // Prepare and execute the statement
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("i", $hostel_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $hostel = $result->fetch_assoc();
        $stmt->close();
    } 
    else {
        echo "<p>Failed to prepare statement.</p>";
        exit;
    }

    if ($hostel) {
        // Assign fetched data to variables
        $total_flat_space = number_format($hostel['total_flat_space'], 2) . ' m²'; // Convert to string with unit
    } 
    else {
        echo "<p>No details found for the specified hostel.</p>";
        exit;
    }

    // Fetch room details for the specific hostel
    $rooms = [];
    $room_sql = "SELECT * FROM rooms WHERE hostel_id = ?";
    if ($room_stmt = $conn->prepare($room_sql)) {
        $room_stmt->bind_param("i", $hostel_id);
        $room_stmt->execute();
        $room_result = $room_stmt->get_result();
        $rooms = $room_result->fetch_all(MYSQLI_ASSOC);
        $room_stmt->close();
    }

    // Extract floor data from rooms
    $floors = !empty($rooms) ? array_unique(array_column($rooms, 'floor')) : [];
?>


<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

        <title>AccomRez</title>

        <!-- Bootstrap core CSS -->
        <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


        <!-- Additional CSS Files -->
        <link rel="stylesheet" href="assets/css/fontawesome.css">
        <link rel="stylesheet" href="assets/css/templatemo-villa-agency.css">
        <link rel="stylesheet" href="assets/css/owl.css">
        <link rel="stylesheet" href="assets/css/animate.css">
        <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
        <!--

        TemplateMo 591 villa agency

        https://templatemo.com/tm-591-villa-agency

        -->
    </head>

    <style>
      .nav-link {
        display: block;
        padding: 10px;
        margin: 5px 0;
        background-color: #343a40; /* Dark background for buttons */
        color: #fff; /* White text color */
        text-align: center;
        border-radius: 5px; /* Rounded corners */
        cursor: pointer; /* Pointer cursor on hover */
        transition: background-color 0.3s ease; /* Smooth background transition */
      }

      .nav-link:hover {
        background-color: #495057; /* Slightly lighter on hover */
      }

      .floor-container {
        display: flex;
        flex-wrap: wrap; /* Allow room boxes to wrap */
        gap: 10px; /* Space between room boxes */
      }

      .room {
        padding: 15px;
        border-radius: 5px;
        text-align: center;
        cursor: pointer;
        flex: 1 0 30%; /* Flexible width, 30% of the container */
        transition: transform 0.2s; /* Animation for hovering */
      }

      .room:hover {
        transform: scale(1.05); /* Slightly enlarge on hover */
      }

      .vacant {
        background-color: #28a745; /* Green for vacant rooms */
        color: white;
      }

      .partially-occupied {
        background-color: #ffc107; /* Yellow for partially occupied */
        color: black;
      }

      .fully-occupied {
        background-color: #dc3545; /* Red for fully occupied */
        color: white;
      }

      .over-occupied {
        background-color: #6c757d; /* Gray for over-occupied */
        color: white;
      }

      .room-details {
        display: none; /* Initially hidden */
        background-color: #f8f9fa; /* Light background */
        padding: 20px;
        border-radius: 5px;
        margin-top: 20px;
      }

      #bookNow {
        margin-top: 10px;
      }
    </style>

    <style>
      .nav-link {
    display: block;
    padding: 10px;
    margin: 5px 0;
    background-color: #343a40; /* Dark background for buttons */
    color: #fff; /* White text color */
    text-align: center;
    border-radius: 5px; /* Rounded corners */
    cursor: pointer; /* Pointer cursor on hover */
    transition: background-color 0.3s ease, transform 0.2s; /* Smooth background transition and hover effect */
}

.nav-link:hover {
    background-color: #495057; /* Slightly lighter on hover */
    transform: scale(1.05); /* Slightly enlarge on hover */
}

.floor-container {
    display: flex;
    flex-wrap: wrap; /* Allow room boxes to wrap */
    gap: 10px; /* Space between room boxes */
}

.room {
    padding: 15px;
    border-radius: 5px;
    text-align: center;
    cursor: pointer;
    flex: 1 0 30%; /* Flexible width, 30% of the container */
    transition: transform 0.2s, box-shadow 0.2s; /* Animation for hovering */
}

.room:hover {
    transform: scale(1.05); /* Slightly enlarge on hover */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Add shadow on hover */
}

.vacant {
    background-color: #28a745; /* Green for vacant rooms */
    color: white;
}

.partially-occupied {
    background-color: #ffc107; /* Yellow for partially occupied */
    color: black;
}

.fully-occupied {
    background-color: #dc3545; /* Red for fully occupied */
    color: white;
}

.over-occupied {
    background-color: #6c757d; /* Gray for over-occupied */
    color: white;
}

.room-details {
    display: none; /* Initially hidden */
    background-color: #f8f9fa; /* Light background */
    padding: 20px;
    border-radius: 5px;
    margin-top: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow to lift the content */
}

#bookNow {
    margin-top: 10px;
    padding: 10px 20px;
    background-color: #007bff; /* Bootstrap primary color */
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

#bookNow:hover {
    background-color: #0056b3; /* Darker shade on hover */
}

    </style>

    <body>

  <!-- ***** Header Area Start ***** -->
  <header class="header-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                    <a href="home.html" class="logo">
                        <h1>AccomRez</h1>
                    </a>
                    <!-- ***** Logo End ***** -->
                    <!-- ***** Menu Start ***** -->
                    <ul class="nav">
                      <li><a href="home.php">Home</a></li>
                      <li><a href="hostels.php">Hostels</a></li>
                      
                      <?php if ($isLoggedIn): ?>
                            <!-- If logged in, show Profile with dropdown -->
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Profile</a>
                                <ul class="dropdown-menu">
                                    <?php if ($isAdmin): ?>
                                        <li><a href="admin_page.php">Admin Dashboard</a></li>
                                    <?php else: ?>
                                        <li><a href="user-profile.php">User Profile</a></li>
                                    <?php endif; ?>
                                    <li><a href="logout.php">Logout</a></li>
                                </ul>
                            </li>
                        <?php else: ?>
                            <!-- If not logged in, show Register/Login -->
                            <li><a href="register_form.php">Register/Login</a></li>
                        <?php endif; ?>
                  </ul>   
                    <!-- ***** Menu End ***** -->
                </nav>
            </div>
        </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <div class="page-heading header-text">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <h3><?php echo htmlspecialchars($hostel['hostel_name']); ?> - Details</h3>
        </div>
      </div>
    </div>
  </div>

  <div class="single-property section">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <div class="main-image">
            <img src="<?php echo htmlspecialchars($hostel['hostel_path']); ?>" alt="Hostel Image">
          </div>
          <div class="main-content">
            <h2><?php echo htmlspecialchars($hostel['hostel_name']); ?></h2>
            <h5>City: <?php echo htmlspecialchars($hostel['city']); ?></h5>
            <h5><?php echo htmlspecialchars($hostel['description']); ?></h5>
            <ul>
                <li>Floors: <span><?php echo htmlspecialchars($hostel['num_floors']); ?></span></li>
                <li>Rooms: <span><?php echo htmlspecialchars($hostel['num_rooms']); ?></span></li>
                <li>Vacancies: <span><?php echo htmlspecialchars($hostel['total_vacancies']); ?></span></li>
                <li>Contact: <span><?php echo htmlspecialchars($hostel['email']); ?></span></li>
                <li>Phone: <span><?php echo htmlspecialchars($hostel['phone']); ?></span></li>
            </ul>
          </div> 
        </div>

        <div class="col-lg-4">
          <div class="info-table">
            <ul>
              <li>
                <img src="assets/images/info-icon-01.png" alt="" style="max-width: 52px;">
                <h4><?php echo $total_flat_space; ?><br><span>Max Room Space</span></h4>
              </li>
              <li>
                <img src="assets/images/info-icon-04.png" alt="" style="max-width: 52px;">
                <h4>Safety<br><span>24/7 Under Control</span></h4>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="section best-deal">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="tabs-content">
            <div class="row">              
              <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="appartment" role="tabpanel" aria-labelledby="appartment-tab">
                  <div class="row">
                    <div class="col-lg-3">
                      <div class="info-table">
                      <nav class="nav flex-column">
                        <?php
                          $floors = array_unique(array_column($rooms, 'floor'));
                          foreach ($floors as $floor) {
                            echo "<a class='nav-link' href='javascript:void(0);' data-floor='$floor'>Floor $floor</a>";
                          }
                        ?>
                      </nav>
                      </div>
                    </div>
                    <div class="col-lg-3">
                      <div id="floorContainer" class="floor-container"></div>
                    </div>
                    <div class="col-lg-3">
                    <div id="roomDetails" class="room-details">
                      <div id="roomInfo"></div>  
                      <button id="bookNow">Book Now</button>
                    </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/counter.js"></script>
  <script src="assets/js/custom.js"></script>

  <script>
    document.addEventListener("DOMContentLoaded", function() {
        const rooms = <?php echo json_encode($rooms); ?>;
        const floorContainer = document.getElementById('floorContainer');
        const roomDetails = document.getElementById('roomDetails');
        const roomInfo = document.getElementById('roomInfo');
        const bookNowButton = document.getElementById('bookNow');

        function displayRooms(floor) {
            floorContainer.innerHTML = '';
            rooms.filter(room => room.floor == floor).forEach(room => {
                const roomDiv = document.createElement('div');
                roomDiv.className = `room ${getRoomStatusClass(room.people, room.capacity)}`;
                roomDiv.innerText = `Room ${room.room_number}`;
                roomDiv.onclick = () => showRoomDetails(room);
                floorContainer.appendChild(roomDiv);
            });
        }

        function getRoomStatusClass(people, capacity) {
            if (people == 0) return 'vacant';
            if (people < capacity-1) return 'partially-occupied';
            if (people == capacity-1) return 'fully-occupied';
            return 'over-occupied';
        }

        function showRoomDetails(room) {
            roomInfo.innerHTML = `
                <p>Room Number: ${room.room_number}</p>
                <p>Capacity: ${room.capacity}</p>
                <p>Occupied: ${room.people}</p>
                <p>Furniture: ${room.furniture_type}</p>
                <p>Accommodation: ${room.accommodation}</p>
            `;
            bookNowButton.onclick = () => bookRoom(room.id, room.room_number); // Capture room id and room number here
            roomDetails.style.display = 'block';
        }

        function bookRoom(roomId, roomNumber) {
            alert(`Booking room ${roomNumber}`);

            // Redirect to advance_booking.php with room id
            window.location.href = `advance_booking.php?id=${roomId}`;
        }

        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', function() {
                displayRooms(this.getAttribute('data-floor'));
            });
        });

        // Initially display rooms for the first floor if available
        if (floors.length > 0) {
            displayRooms(floors[0]);
        }
    });
</script>
  <script src="assets/js/headerdropdown.js"></script>

  </body>
</html>