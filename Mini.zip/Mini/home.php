<?php 
    @include 'config.php';
?>

<?php
   session_start(); // Start the session 

   // Check if the user is logged in as either admin or user
   $isLoggedIn = isset($_SESSION['admin_id']) || isset($_SESSION['user_id']);
   $isAdmin = isset($_SESSION['admin_id']);
?>

<?php
    $result = $conn->query("SELECT COUNT(*) AS total_hostels FROM hostels");
    $total_hostels = $result->fetch_assoc()['total_hostels'];
    $result = $conn->query("SELECT COUNT(DISTINCT city) AS total_cities FROM hostels");
    $total_cities = $result->fetch_assoc()['total_cities'];
?>


<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <title>AccomRez</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-villa-agency.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
<!--

TemplateMo 591 villa agency

https://templatemo.com/tm-591-villa-agency

-->
  </head>

<body>

  <!-- ***** Header Area Start ***** -->
  <header class="header-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                    <a href="home.html" class="logo">
                        <h1>AccomRez</h1>
                    </a>
                    <!-- ***** Logo End ***** -->
                    <!-- ***** Menu Start ***** -->
                    <ul class="nav">
                      <li><a href="home.php" class="active">Home</a></li>
                      <li><a href="hostels.php">Hostels</a></li>
                      
                      <?php if ($isLoggedIn): ?>
                            <!-- If logged in, show Profile with dropdown -->
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Profile</a>
                                <ul class="dropdown-menu">
                                    <?php if ($isAdmin): ?>
                                        <li><a href="admin_page.php">Admin Dashboard</a></li>
                                    <?php else: ?>
                                        <li><a href="user-profile.php">User Profile</a></li>
                                    <?php endif; ?>
                                    <li><a href="logout.php">Logout</a></li>
                                </ul>
                            </li>
                        <?php else: ?>
                            <!-- If not logged in, show Register/Login -->
                            <li><a href="register_form.php">Register/Login</a></li>
                        <?php endif; ?>
                  </ul>   
                    <!-- ***** Menu End ***** -->
                </nav>
            </div>
        </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <div class="fun-facts">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="wrapper">
            <div class="row">
              <div class="col-lg-4">
                <div class="counter">
                  <h2 class="timer count-title count-number" data-to="<?php echo $total_hostels; ?>" data-speed="1000"></h2>
                   <p class="count-text ">Hostels</p>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="counter">
                  <h2 class="timer count-title count-number" data-to="4" data-speed="1000"></h2>
                  <p class="count-text ">Rating</p>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="counter">
                  <h2 class="timer count-title count-number" data-to="<?php echo $total_cities; ?>" data-speed="1000"></h2>
                  <p class="count-text ">Cities</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  

  <div class="properties section">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 offset-lg-4">
          <div class="section-heading text-center">
            <h2> Hostels</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <?php
            $sql = "SELECT h.id,h.hostel_name, h.city, h.description, h.num_floors, h.num_rooms, h.email, h.phone, h.hostel_path, 
                SUM(r.capacity - r.people) AS total_vacancies
                FROM hostels h
                JOIN rooms r ON h.id = r.hostel_id
                GROUP BY h.id
                ORDER BY total_vacancies DESC
                LIMIT 3";

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    $hostel_id = $row['id'];
                    $hostel_name = $row['hostel_name'];
                    $city = $row['city'];
                    $description = $row['description'];
                    $num_floors = $row['num_floors'];
                    $num_rooms = $row['num_rooms'];
                    $email = $row['email'];
                    $phone = $row['phone'];
                    $hostel_path = $row['hostel_path'];
                    $total_vacancies = $row['total_vacancies'];
            
                    echo '<div    iv class="col-lg-4 col-md-6">';
                    echo '  <div class="item">';
                    echo '    <a href="details.php?id=' . $hostel_id . '"><img src="'.$hostel_path.'" alt="Hostel Image"></a>';
                    echo '    <span class="category">'.$hostel_name.'</span>';
                    echo '    <h6>City: '.$city.'</h6>';
                    echo '    <h4>'.$description.'</h4>';
                    echo '    <ul>';
                    echo '      <li>Floors: <span>'.$num_floors.'</span></li>';
                    echo '      <li>Rooms: <span>'.$num_rooms.'</span></li>';
                    echo '      <li>Vacancies: <span>'.$total_vacancies.'</span></li>';
                    echo '      <li>Contact: <span>'.$email.'</span></li>';
                    echo '      <li>Phone: <span>'.$phone.'</span></li>';
                    echo '    </ul>';
                    echo '    <div class="main-button">';
                    echo '      <a href="details_h.php?id=' . $hostel_id . '">Details</a>';
                    echo '    </div>';
                    echo '  </div>';
                    echo '</div>';
                }
            } 
            else {
                echo "No hostels found.";
            }
        ?>
      </div>
    </div>
  </div>


  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/counter.js"></script>
  <script src="assets/js/custom.js"></script>
  <script src="assets/js/headerdropdown.js"></script>

  </body>
</html>