<?php

    $conn = mysqli_connect('localhost','root','','hostel');
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
?>