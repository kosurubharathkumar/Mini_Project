<?php
session_start();
@include 'config.php';

if (!isset($_SESSION['admin_name'])) {
    header('Location: login.php');
    exit();
}

if (isset($_POST['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit();
}

$admin_id = $_SESSION['admin_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_details'])) {
    // Retrieve form data
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $hname = $_POST['hostel_name'];
    $city = $_POST['city'];
    $description = $_POST['description'];
    $num_floors = $_POST['num_floors'];
    $num_rooms = $_POST['num_rooms'];

    // Prepare SQL statement based on whether admin exists
    $query = "SELECT * FROM hostels WHERE admin_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'i', $admin_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $admin_exists = mysqli_num_rows($result) > 0; 

    if ($admin_exists) {
        $update_query = "UPDATE hostels SET name = ?, email = ?, phone = ?, hostel_name = ?, city = ?, description = ?, num_floors = ?, num_rooms = ? WHERE admin_id = ?";
        $stmt = mysqli_prepare($conn, $update_query);
        mysqli_stmt_bind_param($stmt, 'ssssssiii', $name, $email, $phone, $hname, $city, $description, $num_floors, $num_rooms, $admin_id);
    } else {
        $insert_query = "INSERT INTO hostels (name, email, phone, hostel_name, city, description, num_floors, num_rooms, admin_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $insert_query);
        mysqli_stmt_bind_param($stmt, 'ssssssiii', $name, $email, $phone, $hname, $city, $description, $num_floors, $num_rooms, $admin_id);
    }

    // Execute SQL statement
    $success = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    if ($success) {
        header('Location: profile.php');
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}


$query = "SELECT * FROM hostels WHERE admin_id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, 'i', $admin_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$admin_exists = mysqli_num_rows($result) > 0;
if ($admin_exists) {
    $admin = mysqli_fetch_assoc($result);
}
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>AccomRez</title>
    <link rel="stylesheet" href="assets/Styles/style.css" />
    <link rel="stylesheet" href="assets/Styles/nav.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container-scroller">
        <!-- partial:partials/_sidebar.html -->
        <nav class="sidebar sidebar-offcanvas" id="sidebar">
            <div class="sidebar-brand-wrapper d-none d-lg-flex align-items-center justify-content-center fixed-top">
                <a class="sidebar-brand brand-logo" href="admin_page.php"><span class="logo-text">AccomRez</span></a>
                <a class="sidebar-brand brand-logo-mini" href="admin_page.php"><span class="logo-mini-text">AR</span></a>
            </div>
            <ul class="nav">
                <li class="nav-item profile">
                    <div class="profile-desc">
                        <div class="profile-pic">
                            <div class="count-indicator">
                                <i class="fa-solid fa-user"></i>
                                <span class="count bg-success"></span>
                            </div>
                            <div class="profile-name">
                                <h5 class="mb-0 font-weight-normal"><?php echo $_SESSION['admin_name']; ?></h5>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="nav-item menu-items">
                    <a class="nav-link" href="home.php"><span class="menu-title">Home</span></a>
                </li>
                <li class="nav-item menu-items">
                    <a class="nav-link" href="admin_page.php"><span class="menu-title">Dashboard</span></a>
                </li>
                <li class="nav-item menu-items">
                    <a class="nav-link" href="profile.php"><span class="menu-title">Profile</span></a>
                </li>
                <li class="nav-item menu-items">
                    <a class="nav-link" href="details.php"><span class="menu-title">Hostel details</span></a>
                </li>
            </ul>
        </nav>

        <div class="container-fluid page-body-wrapper" style="margin-bottom: 20px;">
            <!-- partial:partials/_navbar.html -->
            <nav class="navbar p-0 fixed-top d-flex flex-row">
                <div class="navbar-brand-wrapper d-flex d-lg-none align-items-center justify-content-center">
                    <a class="sidebar-brand brand-logo-mini" href="admin_page.php"><span class="logo-mini-text">AR</span></a>
                </div>
                <div class="navbar-menu-wrapper flex-grow d-flex align-items-stretch">
                    <ul class="navbar-nav w-100">
                        <li class="nav-item w-100"></li>
                    </ul>
                    <ul class="navbar-nav navbar-nav-right">
                        <li class="nav-item dropdown">
                            <a class="nav-link" id="profileDropdown" href="profile.php">
                                <div class="navbar-profile">
                                    <i class="fa-solid fa-user"></i>
                                    <p class="mb-0 d-none d-sm-block navbar-profile-name"><?php echo $_SESSION['admin_name']; ?></p>
                                </div>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link" href="#">
                                <form method="post">
                                    <button class="btn btn-link" type="submit" name="logout">
                                        <i class="fa-solid fa-sign-out-alt"></i>
                                    </button>
                                </form>
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="row">
                        <div class="col-12 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">Admin Details</h4>
                                    <form class="forms-sample" method="post" action="profile.php">
                                        <input type="hidden" name="update_details" value="1">
                                        <div class="form-group">
                                            <label for="exampleInputName1">Name</label>
                                            <input type="text" class="form-control" id="exampleInputName1" name="name" placeholder="Name" value="<?php if($admin_exists) echo htmlspecialchars($admin['name']); ?>"/>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputPhone1">Phone no</label>
                                            <input type="text" class="form-control" id="exampleInputPhone1" name="phone" placeholder="Phone number" value="<?php if($admin_exists) echo htmlspecialchars($admin['phone']); ?>"/>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail3">Email address</label>
                                            <input type="email" class="form-control" id="exampleInputEmail3" name="email" placeholder="Email" value="<?php if($admin_exists) echo htmlspecialchars($admin['email']); ?>"/>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputHostelName1">Hostel Name</label>
                                            <input type="text" class="form-control" id="exampleInputHostelName1" name="hostel_name" placeholder="Hostel Name" value="<?php if($admin_exists) echo htmlspecialchars($admin['hostel_name']); ?>"/>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputNumFloors">Number of Floors</label>
                                            <input type="number" class="form-control" id="exampleInputNumFloors" name="num_floors" placeholder="Number of Floors" value="<?php if($admin_exists) echo htmlspecialchars($admin['num_floors']); ?>"/>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputNumRooms">Number of Rooms</label>
                                            <input type="number" class="form-control" id="exampleInputNumRooms" name="num_rooms" placeholder="Number of Rooms" value="<?php if($admin_exists) echo htmlspecialchars($admin['num_rooms']); ?>"/>
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleInputCity1">City</label>
                                            <input type="text" class="form-control" id="exampleInputCity1" name="city" placeholder="City" value="<?php if($admin_exists) echo htmlspecialchars($admin['city']); ?>"/>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleTextarea1">Textarea</label>
                                            <textarea class="form-control" id="exampleTextarea1" rows="4" name="description"><?php if($admin_exists) echo htmlspecialchars($admin['description']); ?></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-primary mr-2">Submit</button>
                                        <button class="btn btn-dark">Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <footer class="footer">
                    <div class="d-sm-flex justify-content-center justify-content-sm-between"></div>
                </footer>
            </div>
        </div>
    </div>
</body>
</html>
