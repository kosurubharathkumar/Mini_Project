<?php
session_start();
@include 'config.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    //exit();
}

$user_id = $_SESSION['user_id'];

if (isset($_GET['id'])) {
    $room_id = $_GET['id'];

    // Fetch room details
    $query_room = "SELECT * FROM rooms WHERE id='$room_id'";
    $result_room = mysqli_query($conn, $query_room);
    $room = mysqli_fetch_assoc($result_room);

    if (!$room) {
        echo "Room not found.";
        exit();
    }

    // Fetch hostel details
    $hostel_id = $room['hostel_id'];
    $query_hostel = "SELECT * FROM hostels WHERE id='$hostel_id'";
    $result_hostel = mysqli_query($conn, $query_hostel);
    $hostel = mysqli_fetch_assoc($result_hostel);

    if (!$hostel) {
        echo "Hostel not found.";
        exit();
    }

    // Check if the user is already in a hostel
    $query_student = "SELECT * FROM students WHERE admin_id='$user_id'";
    $result_student = mysqli_query($conn, $query_student);
    $student = mysqli_fetch_assoc($result_student);

    $booking_successful = false;
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['confirm_change']) && $_POST['confirm_change'] == '1') {
            // User confirmed to change the hostel
            $previous_room_id = $student['room_id'];

            // Update the student table with new room details
            $update_student = "UPDATE students SET hostel_name='{$hostel['hostel_name']}', room_id='$room_id' WHERE admin_id='$user_id'";
            mysqli_query($conn, $update_student);

            // Decrease the count of people in the previous room
            $update_previous_room = "UPDATE rooms SET people = people - 1 WHERE id='$previous_room_id'";
            mysqli_query($conn, $update_previous_room);

            // Increase the count of people in the new room
            $update_new_room = "UPDATE rooms SET people = people + 1 WHERE id='$room_id'";
            mysqli_query($conn, $update_new_room);

            // Insert into bookings table for a month-long booking
            $start_date = date('Y-m-d');
            $end_date = date('Y-m-d', strtotime('+1 month', strtotime($start_date)));
            $insert_booking = "INSERT INTO bookings (user_id, admin_id, room_id, start_date, end_date) VALUES ('$user_id', '{$hostel['admin_id']}', '$room_id', '$start_date', '$end_date')";
            mysqli_query($conn, $insert_booking);

            $booking_successful = true;

            $query_user_email = "SELECT email FROM users WHERE id='$user_id'";
            $result_user_email = mysqli_query($conn, $query_user_email);
            $user_email = mysqli_fetch_assoc($result_user_email)['email'];

            $query_admin_email = "SELECT email FROM users WHERE id='{$hostel['admin_id']}'";
            $result_admin_email = mysqli_query($conn, $query_admin_email);
            $admin_email = mysqli_fetch_assoc($result_admin_email)['email'];

            // Send email confirmation
            $to = $user_email; // Replace with the user's email fetched from database
            $subject = 'Booking Confirmation';
            $message = "Dear User,\n\nYour booking for Room {$room['room_number']} at {$hostel['hostel_name']} has been confirmed.\n\nThank you for choosing our service.";
            $headers = "From: $admin_email\r\n";
            $headers .= "Reply-To: $admin_email\r\n";
            $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

            // Uncomment to send email
            mail($to, $subject, $message, $headers);
        } else {
            // New booking
            if ($student) {
                echo '<script>';
                echo 'if (confirm("You are already in a hostel. Do you want to change your hostel?")) {';
                echo '  var form = document.createElement("form");';
                echo '  form.method = "post";';
                echo '  var input = document.createElement("input");';
                echo '  input.type = "hidden";';
                echo '  input.name = "confirm_change";';
                echo '  input.value = "1";';
                echo '  form.appendChild(input);';
                echo '  document.body.appendChild(form);';
                echo '  form.submit();';
                echo '} else {';
                echo '  window.location.href = "hostels.php";'; // Redirect to another page if not confirmed
                echo '}';
                echo '</script>';
            } else {
                // Insert new student record
                $user_name=$_SESSION['user_name'];
                $insert_student = "INSERT INTO students (admin_id, student_name, student_fathername, hostel_name, room_id, cell_no, age, dob, fee_date, fee_status) VALUES ('$user_id', '$user_name', 'Father Name', '{$hostel['hostel_name']}', '$room_id', '1234567890', 20, '2000-01-01', NOW(), 'paid')";
                mysqli_query($conn, $insert_student);

                // Increase the count of people in the room
                $update_new_room = "UPDATE rooms SET people = people + 1 WHERE id='$room_id'";
                mysqli_query($conn, $update_new_room);

                // Insert into bookings table for a month-long booking
                $start_date = date('Y-m-d');
                $end_date = date('Y-m-d', strtotime('+1 month', strtotime($start_date)));
                $insert_booking = "INSERT INTO bookings (user_id, admin_id, room_id, start_date, end_date) VALUES ('$user_id', '{$hostel['admin_id']}', '$room_id', '$start_date', '$end_date')";
                mysqli_query($conn, $insert_booking);

                $booking_successful = true;

                $query_user_email = "SELECT email FROM users WHERE id='$user_id'";
                $result_user_email = mysqli_query($conn, $query_user_email);
                $user_email = mysqli_fetch_assoc($result_user_email)['email'];

                $query_admin_email = "SELECT email FROM users WHERE id='{$hostel['admin_id']}'";
                $result_admin_email = mysqli_query($conn, $query_admin_email);
                $admin_email = mysqli_fetch_assoc($result_admin_email)['email'];

                // Send email confirmation
                $to = $user_email; // Replace with the user's email fetched from database
                $subject = 'Booking Confirmation';
                $message = "Dear User,\n\nYour booking for Room {$room['room_number']} at {$hostel['hostel_name']} has been confirmed.\n\nThank you for choosing our service.";
                $headers = "From: $admin_email\r\n";
                $headers .= "Reply-To: $admin_email\r\n";
                $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

                // Uncomment to send email
                mail($to, $subject, $message, $headers);
            }
        }
    }
} else {
    echo "No room selected.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room Booking</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            <?php if ($booking_successful): ?>
                alert("Room booked successfully! Check your email for confirmation.");
                window.location.href = "home.php";  // Change to your desired redirect page
            <?php endif; ?>
        });
    </script>
</head>
<body>
<div class="container">
    <h1 class="my-4"><?php echo htmlspecialchars($hostel['hostel_name']); ?> - Room Booking</h1>
    <h2>Hostel Details</h2>
    <p><strong>City:</strong> <?php echo htmlspecialchars($hostel['city']); ?></p>
    <p><strong>Description:</strong> <?php echo htmlspecialchars($hostel['description']); ?></p>
    <p><strong>Floors:</strong> <?php echo htmlspecialchars($hostel['num_floors']); ?></p>
    <p><strong>Rooms:</strong> <?php echo htmlspecialchars($hostel['num_rooms']); ?></p>
    <p><strong>Contact:</strong> <?php echo htmlspecialchars($hostel['phone']); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($hostel['email']); ?></p>

    <h2 class="my-4">Room Details</h2>
    <p><strong>Room Number:</strong> <?php echo htmlspecialchars($room['room_number']); ?></p>
    <p><strong>Floor:</strong> <?php echo htmlspecialchars($room['floor']); ?></p>
    <p><strong>Capacity:</strong> <?php echo htmlspecialchars($room['capacity']); ?></p>
    <p><strong>Occupied:</strong> <?php echo htmlspecialchars($room['people']); ?></p>
    <p><strong>Furniture:</strong> <?php echo htmlspecialchars($room['furniture_type']); ?></p>
    <p><strong>Beds:</strong> <?php echo htmlspecialchars($room['beds']); ?></p>
    <p><strong>Chairs:</strong> <?php echo htmlspecialchars($room['chairs']); ?></p>
    <p><strong>Tables:</strong> <?php echo htmlspecialchars($room['tables']); ?></p>
    <p><strong>Accommodation:</strong> <?php echo htmlspecialchars($room['accommodation']); ?></p>

    <form method="post">
        <button type="submit" name="book_room" class="btn btn-primary">Book Now</button>
    </form>
</div>
</body>
</html>

<?php
mysqli_close($conn);
?>
