document.addEventListener("DOMContentLoaded", function () {
  const dropdown = document.querySelector(".dropdown-toggle");
  if (dropdown) {
    dropdown.addEventListener("click", function (e) {
      e.preventDefault();
      const menu = this.nextElementSibling;
      menu.classList.toggle("show");
    });
  }
});
