<?php
session_start();
@include 'config.php';

if (!isset($_SESSION['admin_name'])) {
    header('Location: login.php');
    exit();
}

if (isset($_POST['logout'])) {
    session_destroy();
    header('Location: login.php');
    exit();
}

$admin_id = $_SESSION['admin_id'];

// Fetch hostel details to populate form and validate room count
$query_hostel = "SELECT * FROM hostels WHERE admin_id = ?";
$stmt_hostel = mysqli_prepare($conn, $query_hostel);
mysqli_stmt_bind_param($stmt_hostel, 'i', $admin_id);
mysqli_stmt_execute($stmt_hostel);
$result_hostel = mysqli_stmt_get_result($stmt_hostel);

if (mysqli_num_rows($result_hostel) > 0) {
    $hostel = mysqli_fetch_assoc($result_hostel);
    $hostel_id = $hostel['id'];
    $num_floors = $hostel['num_floors'];
    $num_rooms_total = $hostel['num_rooms'];
} else {
    echo "Hostel details not found for this admin.";
    exit();
}

// Handle form submission to insert rooms
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_rooms'])) {
    $rooms_data = $_POST['rooms'];

    // Validate the total number of rooms
    $total_rooms_entered = 0;
    foreach ($rooms_data as $floor_rooms) {
        $total_rooms_entered += count($floor_rooms);
    }

    if ($total_rooms_entered != $num_rooms_total) {
        echo "Error: The total number of rooms entered ($total_rooms_entered) does not match the total number of rooms in the hostel ($num_rooms_total).";
    } else {
        $error = false;
        foreach ($rooms_data as $floor => $floor_rooms) {
            foreach ($floor_rooms as $room_number => $room) {
                $length = mysqli_real_escape_string($conn, $room['length']);
                $width = mysqli_real_escape_string($conn, $room['width']);
                $capacity = mysqli_real_escape_string($conn, $room['capacity']);
                $people = mysqli_real_escape_string($conn, $room['people']);
                $furniture_type = mysqli_real_escape_string($conn, $room['furniture_type']);
                $beds = isset($room['beds']) ? mysqli_real_escape_string($conn, $room['beds']) : 1;
                $chairs = isset($room['chairs']) ? mysqli_real_escape_string($conn, $room['chairs']) : 2;
                $tables = isset($room['tables']) ? mysqli_real_escape_string($conn, $room['tables']) : 1;
                $accommodation = mysqli_real_escape_string($conn, $room['accommodation']);

                // Insert room into database
                $insert_query = "INSERT INTO rooms (admin_id, hostel_id, floor, room_number, length, width, capacity, people, furniture_type, beds, chairs, tables, accommodation)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = mysqli_prepare($conn, $insert_query);
                mysqli_stmt_bind_param($stmt, 'iiisddiisiiis', $admin_id, $hostel_id, $floor, $room_number, $length, $width, $capacity, $people, $furniture_type, $beds, $chairs, $tables, $accommodation);
                $success = mysqli_stmt_execute($stmt);
                if (!$success) {
                    $error = true;
                    echo "Error inserting room: " . mysqli_error($conn);
                    break;
                }
            }
            if ($error) break;
        }

        if (!$error) {
            echo "Rooms added successfully.";
        }
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>AccomRez</title>
    <link rel="stylesheet" href="assets/Styles/style.css" />
    <link rel="stylesheet" href="assets/Styles/nav.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container-scroller">
    <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <div class="sidebar-brand-wrapper d-none d-lg-flex align-items-center justify-content-center fixed-top">
          <a class="sidebar-brand brand-logo" href="admin_page.php"><span class="logo-text">AccomRez</span></a><!--logo-->
          <a class="sidebar-brand brand-logo-mini" href="admin_page.php"><span class="logo-mini-text">AR</span></a><!--mini logo-->
        </div>
        <ul class="nav">
            <li class="nav-item profile">
                <div class="profile-desc">
                    <div class="profile-pic">
                        <div class="count-indicator">
                            <i class="fa-solid fa-user"></i>
                            <span class="count bg-success"></span>
                        </div>
                        <div class="profile-name"><h5 class="mb-0 font-weight-normal"><?php echo $_SESSION['admin_name']; ?></h5></div>
                    </div>
                </div>
            </li>
            <li class="nav-item menu-items">
                <a class="nav-link" href="home.php"><span class="menu-title">Home</span></a>
            </li>
            <li class="nav-item menu-items">
                <a class="nav-link" href="admin_page.php"><span class="menu-title">Dashboard</span></a>
            </li>
            <li class="nav-item menu-items">
            <a class="nav-link" href="profile.php"><span class="menu-title">Profile</span></a>
          </li>

          <li class="nav-item menu-items">
            <a class="nav-link" href="details.php"><span class="menu-title">Hostel details</span></a>
          </li>
        </ul>
    </nav>

    <div class="container-fluid page-body-wrapper" style="margin-bottom: 20px;">
        <nav class="navbar p-0 fixed-top d-flex flex-row">
            <div class="navbar-brand-wrapper d-flex d-lg-none align-items-center justify-content-center">
            <a class="sidebar-brand brand-logo-mini" href="admin_page.php"><span class="logo-mini-text">AR</span></a><!--mini logo-->
            </div>
            <div class="navbar-menu-wrapper flex-grow d-flex align-items-stretch">
                <ul class="navbar-nav w-100">
                    <li class="nav-item w-100"></li>
                </ul>
                <ul class="navbar-nav navbar-nav-right">
                    <li class="nav-item dropdown border-left"></li>
                    <li class="nav-item dropdown border-left"></li>
                    <li class="nav-item dropdown">
                        <a class="nav-link" id="profileDropdown" href="profile.php" data-toggle="dropdown">
                            <div class="navbar-profile">
                                <i class="fa-solid fa-user"></i>
                                <p class="mb-0 d-none d-sm-block navbar-profile-name"><?php echo $_SESSION['admin_name']; ?></p>
                            </div>
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link" href="#">
                            <form method="post">
                                <button class="btn btn-link" type="submit" name="logout">
                                    <i class="fa-solid fa-sign-out-alt"></i>
                                </button>
                            </form>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <div class="main-panel">
            <div class="content-wrapper">
                <div class="row">
                    <div class="col-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Hostel Details Table</h4>
                                <form class="forms-sample" method="post" action="details.php">
                                    <?php
                                    for ($floor = 1; $floor <= $num_floors; $floor++) {
                                        echo "<h2>Floor $floor</h2>";
                                        echo "<div id='floor_$floor'>";
                                        echo "<button type='button' class='btn btn-success add-room-btn' data-floor='$floor'>Add Room on Floor $floor</button>";
                                        echo "</div>";
                                        echo "<br><br>";
                                    }
                                    ?>
                                    <button type="submit" name="submit_rooms" class="btn btn-primary mr-2">Submit Rooms</button>
                                    <button class="btn btn-dark">Cancel</button>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>

                
            </div>
            <footer class="footer">
                <div class="d-sm-flex justify-content-center justify-content-sm-between">
                    <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">AccomRez Copyright © 2023. All rights reserved.</span>
                </div>
            </footer>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    var roomCounter = {};
    for (var floor = 1; floor <= <?php echo $num_floors; ?>; floor++) {
        roomCounter[floor] = 0;
    }

    $('.add-room-btn').click(function() {
        var floor = $(this).data('floor');
        roomCounter[floor]++;

        var roomHtml = `
            <div class="room" data-floor="${floor}" data-room="${roomCounter[floor]}">
                <h3>Room ${roomCounter[floor]}</h3>
                <div class="form-group">
                    <label for="length_${floor}_${roomCounter[floor]}">Length</label>
                    <input type="number" class="form-control" name="rooms[${floor}][${roomCounter[floor]}][length]" id="length_${floor}_${roomCounter[floor]}" placeholder="Length">
                </div>
                <div class="form-group">
                    <label for="width_${floor}_${roomCounter[floor]}">Width</label>
                    <input type="number" class="form-control" name="rooms[${floor}][${roomCounter[floor]}][width]" id="width_${floor}_${roomCounter[floor]}" placeholder="Width">
                </div>
                <div class="form-group">
                    <label for="capacity_${floor}_${roomCounter[floor]}">Capacity</label>
                    <input type="number" class="form-control" name="rooms[${floor}][${roomCounter[floor]}][capacity]" id="capacity_${floor}_${roomCounter[floor]}" placeholder="Capacity">
                </div>
                <div class="form-group">
                    <label for="people_${floor}_${roomCounter[floor]}">People</label>
                    <input type="number" class="form-control" name="rooms[${floor}][${roomCounter[floor]}][people]" id="people_${floor}_${roomCounter[floor]}" placeholder="People">
                </div>
                <div class="form-group">
                    <label for="furniture_type_${floor}_${roomCounter[floor]}">Furniture Type</label>
                    <input type="text" class="form-control" name="rooms[${floor}][${roomCounter[floor]}][furniture_type]" id="furniture_type_${floor}_${roomCounter[floor]}" placeholder="Furniture Type">
                </div>
                <div class="form-group">
                    <label for="beds_${floor}_${roomCounter[floor]}">Beds</label>
                    <input type="number" class="form-control" name="rooms[${floor}][${roomCounter[floor]}][beds]" id="beds_${floor}_${roomCounter[floor]}" placeholder="Beds">
                </div>
                <div class="form-group">
                    <label for="chairs_${floor}_${roomCounter[floor]}">Chairs</label>
                    <input type="number" class="form-control" name="rooms[${floor}][${roomCounter[floor]}][chairs]" id="chairs_${floor}_${roomCounter[floor]}" placeholder="Chairs">
                </div>
                <div class="form-group">
                    <label for="tables_${floor}_${roomCounter[floor]}">Tables</label>
                    <input type="number" class="form-control" name="rooms[${floor}][${roomCounter[floor]}][tables]" id="tables_${floor}_${roomCounter[floor]}" placeholder="Tables">
                </div>
                <div class="form-group">
                    <label for="accommodation_${floor}_${roomCounter[floor]}">Accommodation</label>
                    <input type="text" class="form-control" name="rooms[${floor}][${roomCounter[floor]}][accommodation]" id="accommodation_${floor}_${roomCounter[floor]}" placeholder="Accommodation">
                </div>
                <button type="button" class="btn btn-danger remove-room-btn" data-floor="${floor}" data-room="${roomCounter[floor]}">Remove Room</button>
            </div>
        `;

        $('#floor_' + floor).append(roomHtml);
    });

    $(document).on('click', '.remove-room-btn', function() {
        var floor = $(this).data('floor');
        var room = $(this).data('room');
        $(this).closest('.room').remove();
        roomCounter[floor]--;
    });
});
</script>
</body>
</html>
