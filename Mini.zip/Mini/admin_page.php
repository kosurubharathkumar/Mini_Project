<?php
    session_start();
    @include 'config.php';

    if(!isset($_SESSION['admin_name'])){
        header('Location: login.php');
        exit();
    }

    if(isset($_POST['logout'])){
        session_destroy();
        header('Location: login.php');
        exit();
    }

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <title>AccomRez</title>

    <link rel="stylesheet" href="assets/Styles/style.css" />
    <link rel="stylesheet" href="assets/Styles/nav .css" />
    <link rel="stylesheet"href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>

    <!-- End layout styles -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script>
      document.addEventListener("DOMContentLoaded", function() {
        document.querySelector("#gear-button").addEventListener("click", function() {
          alert("hi");
        });
      });
      </script>
    
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <div class="sidebar-brand-wrapper d-none d-lg-flex align-items-center justify-content-center fixed-top">
          <a class="sidebar-brand brand-logo" href="admin_page.php"><span class="logo-text">AccomRez</span></a><!--logo-->
          <a class="sidebar-brand brand-logo-mini" href="admin_page.php"><span class="logo-mini-text">AR</span></a><!--mini logo-->
        </div>

        <ul class="nav">
          <li class="nav-item profile">
            <div class="profile-desc">
              <div class="profile-pic">
                <div class="count-indicator"><i class="fa-solid fa-user"></i><!--profile--><span class="count bg-success"></span></div>
                <div class="profile-name"><h5 class="mb-0 font-weight-normal"><?php echo $_SESSION['admin_name']; ?></h5></div>
              </div>
              <a href="#" id="profile-dropdown" data-toggle="dropdown"><i class="fa-solid fa-bars"></i></a>
              <div class="dropdown-menu dropdown-menu-right sidebar-dropdown preview-list" aria-labelledby="profile-dropdown">
                <a href="#" class="dropdown-item preview-item">
                  <div class="preview-thumbnail">
                    <div class="preview-icon bg-dark rounded-circle"><i class="fa-solid fa-gear"></i></div>
                  </div>
                  <div class="preview-item-content">
                    <p class="preview-subject ellipsis mb-1 text-small">Account settings</p>
                  </div>
                </a>
                <div class="dropdown-divider"></div>
                <a href="#" class="dropdown-item preview-item">
                  <div class="preview-thumbnail">
                    <div class="preview-icon bg-dark rounded-circle"><i class="fa-solid fa-key"></i></div>
                  </div>
                  <div class="preview-item-content">
                    <p class="preview-subject ellipsis mb-1 text-small">Change Password</p>
                  </div>
                </a>
              </div>
            </div>
          </li>

          <li class="nav-item menu-items">
            <a class="nav-link" href="home.php"><span class="menu-title">Home</span></a>
          </li>
          <li class="nav-item menu-items">
            <a class="nav-link" href="admin_page.php"><span class="menu-title">Dashboard</span></a>
          </li>

          <li class="nav-item menu-items">
            <a class="nav-link" href="profile.php"><span class="menu-title">Profile</span></a>
          </li>

          <li class="nav-item menu-items">
            <a class="nav-link" href="details.php"><span class="menu-title">Hostel details</span></a>
          </li>
          
        </ul>
      </nav>


      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_navbar.html -->
        <nav class="navbar p-0 fixed-top d-flex flex-row">
          <div class="navbar-brand-wrapper d-flex d-lg-none align-items-center justify-content-center">
            <a class="sidebar-brand brand-logo-mini" href="admin_page.php"><span class="logo-mini-text">AR</span></a><!--mini logo-->
          </div>

          <div class="navbar-menu-wrapper flex-grow d-flex align-items-stretch">
            <ul class="navbar-nav w-100">
              <li class="nav-item w-100">
              </li>
            </ul>

            <ul class="navbar-nav navbar-nav-right">
              <li class="nav-item dropdown border-left">
                <!--<a class="nav-link count-indicator dropdown-toggle" id="messageDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
                  <i class="fa-solid fa-envelope"></i><span class="count bg-success"></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="messageDropdown">
                  <h6 class="p-3 mb-0">Messages</h6>
                   msg
                </div>-->
              </li>

              <li class="nav-item dropdown border-left">
                <!--<a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-toggle="dropdown">
                  <i class="fa-solid fa-bell"></i><span class="count bg-danger"></span>
                </a>
                <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
                  <h6 class="p-3 mb-0">Notifications</h6>
                  notifications
                </div>-->
              </li>

              <li class="nav-item dropdown">
                <a class="nav-link" id="profileDropdown" href="profile.php" data-toggle="dropdown">
                  <div class="navbar-profile">
                    <i class="fa-solid fa-user"></i>
                    <p class="mb-0 d-none d-sm-block navbar-profile-name"> <?php echo $_SESSION['admin_name']; ?></p>
                  </div>
                </a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link" href="logout.php">
                    <form method="post">
                        <button class="btn btn-link" type="submit" name="logout">
                            <i class="fa-solid fa-sign-out-alt"></i>
                        </button>
                    </form>
                </a>
              </li>
            </ul>
          </div>
        </nav>

        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">
            <div class="row">
              <div class="col-xl-3 col-sm-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <div class="row">
                      <div class="col-9">
                        <div class="d-flex align-items-center align-self-start"><h3 class="mb-0">
                        <?php
                          // Query to fetch vacancy information for each hostel
                          $query = "SELECT h.id, h.hostel_name, h.city,
                            COUNT(r.id) AS total_rooms,
                            SUM(r.capacity) AS total_capacity,
                            SUM(r.people) AS total_people,
                            (SUM(r.capacity) - SUM(r.people)) AS vacancies
                            FROM hostels h
                            LEFT JOIN rooms r ON h.id = r.hostel_id
                            WHERE h.admin_id = ?
                            GROUP BY h.id";

                          $stmt = mysqli_prepare($conn, $query);
                          if ($stmt) {
                            mysqli_stmt_bind_param($stmt, 'i', $_SESSION['admin_id']);
                            mysqli_stmt_execute($stmt);
                            $result = mysqli_stmt_get_result($stmt);

                            if ($result) {
                              while ($row = mysqli_fetch_assoc($result)) {
                                echo '<div class="col-xl-3 col-sm-6 grid-margin stretch-card">
                                        <div class="card">
                                          <div class="card-body">
                                            <div class="row">
                                              <div class="col-9">
                                                <div class="d-flex align-items-center align-self-start">
                                                  <h3 class="mb-0">' . $row['vacancies'] . '</h3>
                                                </div>
                                              </div>
                                          </div>
                                        </div>
                                      </div>';
                              }
                            } 
                            else {
                              echo "Error: " . mysqli_error($conn);
                            }
                            mysqli_stmt_close($stmt);
                          } 
                          else {
                            echo "Error: " . mysqli_error($conn);
                          }
                        ?>

                        </h3></div>
                      </div>
                    </div>
                    <h6 class="text-muted font-weight-normal">Vacancies</h6>
                  </div>
                </div>
              </div>
            </div>
            
            
            <div class="row">
              <div class="col-12 grid-margin">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Students</h4>
                    <div class="table-responsive">
                      <table class="table">
                        <thead>
                          <tr>
                            <th>Name</th>
                            <th>Floor No</th>
                            <th>Room No</th>
                            <th>Payment Status</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php
                            $query_students = "SELECT s.student_name,r.floor, r.room_number, s.fee_status
                            FROM students s
                            INNER JOIN rooms r ON s.room_id = r.id
                            WHERE r.admin_id = ?";
                            $stmt_students = mysqli_prepare($conn, $query_students);
                            if ($stmt_students) {
                              mysqli_stmt_bind_param($stmt_students, 'i', $_SESSION['admin_id']);
                              mysqli_stmt_execute($stmt_students);
                              $result_students = mysqli_stmt_get_result($stmt_students);

                              if ($result_students) {
                                while ($row_students = mysqli_fetch_assoc($result_students)) {
                                  echo "<tr>";
                                  echo "<td>" . $row_students['student_name'] . "</td>";
                                  echo "<td>". $row_students['floor']."</td>";
                                  echo "<td>" . $row_students['room_number'] . "</td>";
                                  echo "<td>" . $row_students['fee_status'] . "</td>";
                                  echo "</tr>";
                                }
                              } 
                              else {
                                echo "No students found.";
                              }
                              mysqli_stmt_close($stmt_students);
                            } 
                            else {
                              echo "Error: " . mysqli_error($conn);
                            }
                          ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
            </div>
          </footer>
          
        </div>
        <!-- main-panel ends -->
      </div>

      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->

    <!---->
    </script>

    </body>
</html>
