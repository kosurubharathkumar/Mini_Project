<?php

   @include 'config.php';

   if(isset($_POST['submit'])){

      $name = mysqli_real_escape_string($conn, $_POST['name']);
      $email = mysqli_real_escape_string($conn, $_POST['email']);
      $pass = md5($_POST['password']);
      $cpass = md5($_POST['cpassword']);
      $type = $_POST['type'];

      $select = " SELECT * FROM users WHERE email = '$email' && password = '$pass' ";

      $result = mysqli_query($conn, $select);

      if(mysqli_num_rows($result) > 0){
         $error[] = 'user already exist!';
      }
      else{
         if($pass != $cpass){
            $error[] = 'password not matched!';
         }
         else{
            $insert = "INSERT INTO users(name, email, password, type) VALUES('$name','$email','$pass','$type')";
            mysqli_query($conn, $insert);
            header('location:login.php');
         }
      }
   };
?>



<!DOCTYPE html>
<html lang="en">
   <head>
      <title>register form</title>
      <link rel="stylesheet" href="assets/css/styles.css">
   </head>

   <body>
      <div class="form-container">
         <form action="" method="post">
            <h3>register now</h3>
            <?php
               if(isset($error)){
                  foreach($error as $error){
                     echo '<span class="error-msg">'.$error.'</span>';
                  };
               };
            ?>
            <input type="text" name="name" required placeholder="enter your name">
            <input type="email" name="email" required placeholder="enter your email">
            <input type="password" name="password" required placeholder="enter your password">
            <input type="password" name="cpassword" required placeholder="confirm your password">
            <select name="type">
               <option value="">select type</option>
               <option value="user">user</option>
               <option value="admin">admin</option>
            </select>
            <input type="submit" name="submit" value="register now" class="form-btn">
            <p>already have an account? <a href="login.php">login now</a></p>
         </form>
      </div>
   </body>
   
</html>